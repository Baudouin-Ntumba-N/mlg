from django.apps import AppConfig


class LearningConfig(AppConfig):
    name = 'learning'
